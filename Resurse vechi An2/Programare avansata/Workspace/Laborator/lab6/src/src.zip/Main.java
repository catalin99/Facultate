/**
 * @author Loghin L. Alexandru
 * @author Strugari M.A. Stefan-Mihai
 */

import geoshapes.DrawingFrame;

public class Main {

    public static void main(String[] args) {
        new DrawingFrame().setVisible(true);
    }
}
