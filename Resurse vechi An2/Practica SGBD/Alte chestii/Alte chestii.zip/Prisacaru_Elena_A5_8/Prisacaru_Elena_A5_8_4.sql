--4
drop procedure proc_clone;
/
create or replace procedure proc_clone(p_nr_nr_nr_matricol char) is
  interogare varchar2(2000);
  v_st varchar2(2000);
begin
      execute immediate 'create table clone_'||to_char(p_nr_nr_nr_matricol)||' as select * from inf_stud_'||to_char(p_nr_nr_nr_matricol);
end;
/
set serveroutput on;
begin
for i in (select nr_matricol from studenti) loop
    proc_clone(i.nr_matricol);
  end loop;
end;
/
