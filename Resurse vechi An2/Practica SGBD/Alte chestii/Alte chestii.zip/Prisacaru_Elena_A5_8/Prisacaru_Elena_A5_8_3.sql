
drop procedure proc_cursuri;
/
create or replace procedure pr_cursuri(p_id_curs varchar2) is
    v_CursorIDaux  number; 
    v_CreateTableString  varchar2(200);
    v_NUMRows  number;
begin
    v_CursorIDaux := DBMS_SQL.OPEN_CURSOR;
    v_CreateTableString := 'create table carnet_curs_'||p_id_curs||
      '(nr_matricol varchar2(20), nume varchar2(20), prenume varchar2(20), titlu_curs varchar2(20), valoare number(5),data_notare varchar2(20))';
    dbms_sql.parse(v_CursorIDaux,v_CreateTableString,DBMS_SQL.NATIVE);
    v_NumRows:=DBMS_SQL.EXECUTE(v_CursorIDaux);
    dbms_sql.close_cursor(v_CursorIDaux);
end;
/
drop procedure insert_into_table;
/
create procedure insert_into_table (nr_matricol varchar2, nume varchar2, prenume varchar2,id_curs char, titlu_curs varchar2,valoare number, data_notare Date) is
   cur_hdl         integer;
   stmt_str        varchar2(200);
   rows_processed  binary_integer;
begin
   stmt_str := 'insert into carnet_curs_' || id_curs || ' values (:nr_matricol, :nume, :prenume,:id_curs,:titlu_curs,:valoare,:data_notare)';
   cur_hdl := dbms_sql.open_cursor;
   dbms_sql.parse(cur_hdl, stmt_str,dbms_sql.native);
   dbms_sql.bind_variable(cur_hdl, ':nr_matricol', nr_matricol);
   dbms_sql.bind_variable(cur_hdl, ':nume', nume);
   dbms_sql.bind_variable(cur_hdl, ':prenume', prenume);
   dbms_sql.bind_variable(cur_hdl, ':id_curs', id_curs);
   dbms_sql.bind_variable(cur_hdl, ':titlu_curs', titlu_curs);
   dbms_sql.bind_variable(cur_hdl, ':valoare', valoare);
   dbms_sql.bind_variable(cur_hdl, ':data_notare', data_notare);
   rows_processed := dbms_sql.execute(cur_hdl);
   dbms_sql.close_cursor(cur_hdl);
end;
/
set serveroutput on;
begin
  for i in (select id_curs from cursuri) loop
    pr_cursuri(i.id_curs);
  end loop;
end;
/
set serveroutput on;
begin
  for i in (select s.nr_matricol,s.nume,s.prenume,c.id_curs,c.titlu_curs,n.valoare,n.data_notare from studenti s, note n, cursuri c 
            where s.nr_matricol=n.nr_matricol and c.id_curs=n.id_curs) loop
    insert_into_table(i.nr_matricol,i.nume,i.prenume,i.id_curs,i.titlu_curs,i.valoare,i.data_notare);
  end loop;
end;