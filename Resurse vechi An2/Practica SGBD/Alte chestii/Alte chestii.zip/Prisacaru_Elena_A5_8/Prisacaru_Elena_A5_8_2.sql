
--2
drop procedure afiseaza;
/
create or replace procedure afiseaza(p_nr_matricol char) is
cursor informatii is select s.nr_matricol,s.nume,s.prenume,s.an,s.grupa,s.bursa,c.titlu_curs,n.valoare  
                        from studenti s, note n, cursuri c where s.nr_matricol=n.nr_matricol and n.id_curs=c.id_curs and TRIM(p_nr_matricol)=TRIM(s.nr_matricol);
v_nr_matricol studenti.nr_matricol%type;
v_nume studenti.nume%type;
v_prenume studenti.prenume%type;
v_an studenti.an%type;
v_grupa studenti.grupa%type;
v_bursa studenti.bursa%type;
v_titlu_curs cursuri.titlu_curs%type;
v_valoare note.valoare%type;
interogare varchar2(2000);
TYPE cur_typ IS REF CURSOR;
c cur_typ;
begin
  interogare:='select nr_matricol,nume,prenume,an,grupa,bursa,titlu_curs,valoare from inf_stud_'||to_char(p_nr_matricol);
  open c for interogare;
  loop
    fetch c into v_nr_matricol,v_nume, v_prenume, v_an, v_grupa, v_bursa, v_titlu_curs, v_valoare;
    exit when c%notfound;
    dbms_output.put_line(v_nr_matricol||' '||v_nume||' '||v_prenume||' '||v_an||' '||v_grupa||' '||v_bursa||' '||' '||v_titlu_curs||' '||v_valoare);
  end loop;
  close c;
end;
/
set serveroutput on;
begin
for i in (select nr_matricol from studenti) loop
    afiseaza(i.nr_matricol);
  end loop;
end;
/
