--1
begin
  for i in (select nr_matricol from studenti) loop
    execute immediate 'drop table inf_stud_'||to_char(i.nr_matricol);
  end loop;
end;
/
drop procedure detalii_nr_matricol;
/
create or replace procedure detalii_nr_matricol(p_nr_matricol char) is
cursor informatii is select s.nr_matricol,s.nume,s.prenume,s.an,s.grupa,s.bursa,c.titlu_curs,n.valoare  
                        from studenti s, note n, cursuri c where s.nr_matricol=n.nr_matricol and n.id_curs=c.id_curs and TRIM(p_nr_matricol)=TRIM(s.nr_matricol);
v_nr_matricol studenti.nr_matricol%type;
v_nume studenti.nume%type;
v_prenume studenti.prenume%type;
v_an studenti.an%type;
v_grupa studenti.grupa%type;
v_bursa studenti.bursa%type;
v_titlu_curs cursuri.titlu_curs%type;
v_valoare note.valoare%type;
select_inf varchar2(2000);
begin
open informatii;
loop
fetch informatii into v_nr_matricol,v_nume, v_prenume, v_an, v_grupa, v_bursa, v_titlu_curs, v_valoare;
 exit when informatii%NOTFOUND;
      select_inf :='insert into inf_stud_' ||to_char(p_nr_matricol) || ' values(:1,:2,:3,:4,:5,:6,:7,:8)';
      execute immediate select_inf using v_nr_matricol,v_nume,v_prenume,v_an,v_grupa,v_bursa,v_titlu_curs,v_valoare;
end loop;
close informatii;
end;
/
drop procedure proc;
/
create or replace procedure proc(p_nr_nr_matricol char) is
begin
    
      execute immediate 'create table inf_stud_'||to_char(p_nr_nr_matricol)||'
      (nr_matricol char(3),nume varchar2(20),prenume varchar2(20), an number(2),grupa varchar2(2), bursa number(5), titlu_curs varchar2(20), valoare number(5))';
      execute immediate 'begin detalii_nr_matricol('||to_char(p_nr_nr_matricol)||'); end;';
end;
/
set serveroutput on;
begin
  for i in (select nr_matricol from studenti) loop
    proc(i.nr_matricol);
  end loop;
end;
/
