--3
begin
   for cur_rec in (select object_name, object_type from user_objects where object_type in
                             ('TABLE','VIEW','PROCEDURE','FUNCTION','TRIGGER'))
   loop
      begin
         if cur_rec.object_type = 'table'
         then
            execute immediate 'drop '|| cur_rec.object_type|| ' "'|| cur_rec.object_name|| '" cascade constraints';
         else
            execute immediate 'drop '|| cur_rec.object_type|| ' "'|| cur_rec.object_name|| '"';
         end if;
      exception
         when others then
            DBMS_OUTPUT.put_line ('failed: drop '|| cur_rec.object_type|| ' "'|| cur_rec.object_name|| '"');
      end;
   end loop;
end;