
--2
set serveroutput on;
declare
cloneFile utl_file.file_type;
begin
  cloneFile:=utl_file.fopen('FILESQL','cloneFile.sql','w');
  utl_file.fclose(cloneFile);
end;

declare
  cloneFile utl_file.file_type;
  all_data varchar2(2000);
  cursor c_function is select object_name, object_type from user_objects where object_type like 'FUNCTION';
  cursor c_procedure is select object_name, object_type from user_objects where object_type like 'PROCEDURE';
  cursor c_view is select object_name, object_type from user_objects where object_type like 'VIEW';
  cursor c_trigger is select object_name, object_type from user_objects where object_type like 'TRIGGER';
begin
  cloneFile := utl_file.fopen('FILESQL', 'cloneFile.sql', 'w');
  
  for i in c_function loop
    select dbms_metadata.get_ddl(i.object_type,i.object_name) into all_data from dual;
    utl_file.put(cloneFile,all_data || ';' || chr(10) || chr(13));
    utl_file.put(cloneFile, all_data);
  end loop;
  
  for i in c_view loop
    select dbms_metadata.get_ddl(i.object_type, i.object_name) into all_data from dual;
    utl_file.put(cloneFile,all_data || ';' || chr(10) || chr(13));
    utl_file.put(cloneFile, all_data);
  end loop;
  
  for i in c_trigger loop
    select dbms_metadata.get_ddl(i.object_type, i.object_name) into all_data from dual;
    utl_file.put(cloneFile,all_data || ';' || chr(10) || chr(13));
    utl_file.put(cloneFile, all_data);
  end loop;
  
  /*for i in c_procedure loop
    select dbms_metadata.get_ddl(i.object_type,i.object_name) into all_data from dual;
    utl_file.put(cloneFile,all_data || ';' || chr(10) || chr(13));
    utl_file.put(cloneFile, all_data);
  end loop;*/
  
  utl_file.fclose(cloneFile);
end;
/