--1
set serveroutput on;
create or replace view allObjects as select * from ALL_OBJECTS where owner=user;

select count(*) from allObjects;
