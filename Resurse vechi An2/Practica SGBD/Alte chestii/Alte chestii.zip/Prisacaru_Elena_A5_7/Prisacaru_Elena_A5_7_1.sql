--1--4
drop type openFlights;
create type openFlights as object
(
avioane varchar2(20),
rute varchar2(20),
linii_aeriene varchar2(20),
id_number number,
not final member procedure setOpenFlights(av varchar2, rut varchar2, linii varchar2),
final member procedure setAvioane(av varchar2),
constructor function openFlights(avioane varchar2, rute varchar2,linii_aeriene varchar2) return self as result,
constructor function openFlights(rute varchar2) return self as result,
map member function get_id_number return number
)not final;

drop type body openFlights;
create type body openFlights as
  member procedure setOpenFlights(av varchar2, rut varchar2, linii varchar2) is
    v_av varchar2(20);
    v_rut varchar2(20);
    v_linii varchar2(20);
  begin
    v_av:=av;
    v_rut:=rut;
    v_linii:=linii;
    dbms_output.put_line('avioane '||v_av||' rute '||' linii aeriene '||v_linii);
  end setOpenFlights;
  
  final member procedure setAvioane(av varchar2) is
  v_av varchar2(20);
  begin
    v_av:=av;
    dbms_output.put_line(v_av);
  end;
  
  constructor function openFlights(avioane varchar2, rute varchar2,linii_aeriene varchar2) return self as result
  as
  begin
    self.avioane:=avioane;
    self.rute:=rute;
    self.linii_aeriene:=linii_aeriene;
    self.id_number:=null;
    return;
  end;
  
  constructor function openFlights(rute varchar2) return self as result
  as
  begin
    self.avioane:=null;
    self.rute:=rute;
    self.linii_aeriene:=null;
    self.id_number:=null;
    return;
  end;
  
  map member function get_id_number return number as
  begin
      return self.id_number;
  end;
end;

--2
drop table turn_control;
create table turn_control
(
id_turn number(5),
nume_avioane varchar2(20),
rute_preferentile varchar2(20),
obiect openFlights
);

set serveroutput on;
declare
v_first openFlights;
v_second openFlights;
v_third openFlights;
begin
  v_first:=openFlights('avion1','B3','C1',10);
  v_second:=openFlights('avion2','B4','C2',20);
  v_third:=openFlights('avion3','B5','C3',30);
  insert into turn_control values(1,'Airbuss','A5',v_first);
  insert into turn_control values(2,'Blue','A6',v_second);
  insert into turn_control values(5,'Black','A3',v_third);
end;

select * from turn_control order by obiect;

--3
drop type openFlights_child;
create type openFlights_child under openFlights
(
  nr_escale number,
  constructor function openFlights_child(avioane varchar2, rute varchar2,linii_aeriene varchar2) return self as result,
  overriding member procedure setOpenFlights(av varchar2, rut varchar2, linii varchar2)
);

drop type body openFlights_child;
create type body openFlights_child as
constructor function openFlights_child(avioane varchar2, rute varchar2,linii_aeriene varchar2) return self as result
as
begin
  self.avioane:=avioane;
  self.rute:=rute;
  self.linii_aeriene:=linii_aeriene;
  self.id_number:=null;
  return;
end;
  overriding member procedure setOpenFlights(av varchar2, rut varchar2, linii varchar2) as
  v_av varchar2(20);
  v_rut varchar2(20);
  v_linii varchar2(20);
    begin
    v_av:=av;
    v_rut:=rut;
    v_linii:=linii;
    nr_escale:=3;
     dbms_output.put_line('avioane '||v_av||' rute '||v_rut ||' linii aeriene '|| v_linii||' nr escale '||nr_escale);
    end setOpenFlights; 
end;

set serveroutput on;
declare
v_detalii openFlights_child;
begin
  v_detalii:=openFlights_child('Creature','10A','5F');
  v_detalii.setOpenFlights('Creature','10A','5F');
end;
