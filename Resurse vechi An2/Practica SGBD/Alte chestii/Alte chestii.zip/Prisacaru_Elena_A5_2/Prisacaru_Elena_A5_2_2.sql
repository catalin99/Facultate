set serveroutput on;
declare
  v_nume_prof profesori.nume%TYPE;
  v_valoare note.valoare%TYPE;
begin
     select nume into v_nume_prof
              from(select nume, count(d.id_curs) 
                  from profesori p, didactic d 
                        where p.id_prof=d.id_prof
                            group by nume, d.id_prof
                                  order by count(d.id_curs) desc, nume asc) where rownum=1;
      select max(valoare) into v_valoare from  note n, profesori p, cursuri c, didactic d where n.ID_CURS=c.ID_CURS and p.ID_PROF=d.ID_PROF and d.ID_CURS=c.ID_CURS; 
  if(v_valoare = 10)
        then dbms_output.put_line(v_nume_prof || ' ' || length(trim(v_nume_prof)) || ' ' || 'da');
        else dbms_output.put_line(v_nume_prof || ' ' || length(trim(v_nume_prof)) || ' ' || 'nu');
  end if;
end;
