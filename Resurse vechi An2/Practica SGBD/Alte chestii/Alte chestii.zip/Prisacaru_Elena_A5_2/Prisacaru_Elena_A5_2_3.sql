set serveroutput on;
declare
  v_max_data_nastere studenti.data_nastere%TYPE;
  v_min_data_nastere studenti.data_nastere%TYPE;
begin
  select max(data_nastere) 
      into v_max_data_nastere 
          from studenti;
  select min(data_nastere) 
      into v_min_data_nastere 
          from studenti;
  dbms_output.put_line(abs(v_max_data_nastere-v_min_data_nastere));
end;