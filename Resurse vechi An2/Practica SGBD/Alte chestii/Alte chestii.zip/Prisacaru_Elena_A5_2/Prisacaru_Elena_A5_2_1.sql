set serveroutput on;
declare
  v_concatenare varchar2(100);
begin
  select nume || ' ' || prenume 
    into v_concatenare
        from (select nume, prenume 
              from (select nume,prenume 
                    from studenti 
                          order by dbms_random.value) 
                                where rownum=1);
  DBMS_OUTPUT.PUT_LINE(v_concatenare);
end;

set serveroutput on;
declare
  v_nume_random studenti.nume%TYPE;
  v_prenume_random studenti.prenume%TYPE;
begin
  select nume,prenume into v_nume_random,v_prenume_random
      from (select nume, prenume 
            from (select nume, prenume 
                  from studenti
                      order by dbms_random.value) where rownum=1);
            DBMS_OUTPUT.PUT_LINE(v_nume_random || ' ' || v_prenume_random);
end;