--3
drop function detalii_stud;
create function detalii_stud(p_nr_matricol char)
return varchar2 as
  v_nr_matricol char(4);
  v_nume studenti.nume%type;
  v_prenume studenti.nume%type;
  v_grupa studenti.grupa%type;
  v_bursa studenti.bursa%type;
  v_rezultat varchar2(2000);
begin
  select nr_matricol,nume,prenume,grupa,bursa 
      into v_nr_matricol,v_nume,v_prenume,v_grupa,v_bursa 
          from studenti 
              where nr_matricol=p_nr_matricol;
  v_rezultat:=v_nr_matricol || ' ' || v_nume || ' ' || v_prenume || ' ' || v_grupa || ' ' || v_bursa;
  return v_rezultat;
end;


set serveroutput on;
declare
  v_contor number(5);
  v_detalii varchar2(2000);
  v_out_unu number;
  v_out_doi number;
  v_nr_mat studenti.nr_matricol%type;
  cursor lista_nr_matricol is select nr_matricol from studenti;
begin
  open lista_nr_matricol;
  loop
  fetch lista_nr_matricol into v_nr_mat;
  exit when lista_nr_matricol%notfound;
    select detalii_stud(v_nr_mat) into v_detalii from dual;
    dbms_output.put_line(v_detalii);
    calcul_medie(v_nr_mat,p_an=>v_out_unu,p_medie=>v_out_doi);
  end loop;
 close lista_nr_matricol;
end;
