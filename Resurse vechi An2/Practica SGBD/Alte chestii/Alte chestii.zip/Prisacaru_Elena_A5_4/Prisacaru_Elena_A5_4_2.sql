--2
drop procedure calcul_medie;
create procedure calcul_medie (p_nr_matricol in char, p_an out number, p_medie out number) as
v_medie_an_unu note.valoare%type;
v_medie_an_doi note.valoare%type;
begin
  select an into p_an from studenti where p_nr_matricol=nr_matricol;
  select avg(valoare) into v_medie_an_unu from note n, cursuri c where c.an=1 and c.id_curs=n.id_curs and p_nr_matricol=n.nr_matricol;
  select avg(valoare) into v_medie_an_doi from note n, cursuri c where c.an=2 and c.id_curs=n.id_curs and p_nr_matricol=n.nr_matricol;
   if(p_an=3)
    then
    dbms_output.put_line('an: ' || p_an || ' medie: ' || v_medie_an_unu || ' ' || v_medie_an_doi);
      else if(p_an=2)
        then p_medie:=v_medie_an_unu;
        dbms_output.put_line('an: ' || p_an || ' medie: ' || p_medie);
          else if(p_an=1)
            then p_medie:=0;
            dbms_output.put_line('an: ' || p_an || ' medie: ' || p_medie);
          end if;
      end if;
  end if;
end;

set serveroutput on;
declare
  v_out_unu number;
  v_out_doi number;
begin
  calcul_medie('111',p_an=>v_out_unu,p_medie=>v_out_doi);
end;


