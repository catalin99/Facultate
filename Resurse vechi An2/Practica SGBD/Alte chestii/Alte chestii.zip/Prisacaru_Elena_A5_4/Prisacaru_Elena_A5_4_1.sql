--1
drop function randomm;
create function randomm(p_primul number,p_ultimul number) return number as
  v_random number(5):=0;
begin
  v_random:=dbms_random.value(p_primul,p_ultimul);
  return v_random;
end;
 
 
drop function random_grupa;
create function random_grupa return varchar2 as
  v_random_numar number(5);
  v_random_rezultat varchar2(2):=0;
begin
  v_random_numar:=dbms_random.value(1,15);
  select decode(v_random_numar,1,'A1',2,'A2',3,'A3',4,'A4',5,'A5',6,'A6',7,'A7',8,'B1',9,'B2',10,'B3',11,'B4',12,'B5',13,'B6','B7') 
      into v_random_rezultat 
          from dual;
return v_random_rezultat;
end;


drop procedure adauga_note;
create procedure adauga_note(p_nr_matricol char,p_an number) as
  v_contor number(5) :=0;
  v_random_nota note.valoare%type;
  type idList is table of cursuri.id_curs%type;
  v_lista_id idList;
  cursor lista_id is select id_curs from cursuri where an<p_an;
begin
  open lista_id;
  fetch lista_id bulk collect into v_lista_id;
  for v_contor in 1..v_lista_id.count loop
    v_random_nota:=randomm(4,10);
    insert into note values(p_nr_matricol,v_lista_id(v_contor),v_random_nota,null);
  end loop;
  close lista_id;
end;


drop procedure persoana;
create procedure persoana as
  v_contor number(5);
  v_index number(5);
  v_insert number(5):=1;
  v_nr_matricol char(4):=0;
  v_an number(5):=1;
  v_grupa char(2):='A5';
  v_bursa number(6,2):=2;
  v_random number(5):=1;
  type lista is table of prenume.p%type;
  lista_nr_matricol lista;
begin
  select max(nr_matricol) into v_nr_matricol from studenti;
      for v_contor in (select * from nume) loop
      exit when v_insert=2000;
  select p  bulk collect into lista_nr_matricol from prenume;
      for v_index in 1..lista_nr_matricol.count loop
        v_insert:=v_insert+1;
        v_an:=randomm(1,3);
        v_grupa:=random_grupa;
        v_random:=randomm(1,5);
  select decode(v_random,1,450,2,350,3,250,null) into v_bursa from dual;
        v_nr_matricol:=v_nr_matricol+1;
        INSERT INTO studenti VALUES (v_nr_matricol,v_contor.n,lista_nr_matricol(v_index),v_an,v_grupa,v_bursa,null);
        if v_an>1 then
           adauga_note(v_nr_matricol,v_an);
      end if;
      exit when v_insert=2000;
      end loop;
      end loop;
end persoana;


begin
persoana;
end;