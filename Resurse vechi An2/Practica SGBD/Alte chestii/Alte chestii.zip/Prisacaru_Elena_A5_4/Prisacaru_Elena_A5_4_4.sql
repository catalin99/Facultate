--4
drop procedure rata_promovabilitate;
create procedure rata_promovabilitate(p_id_curs in cursuri.id_curs%type) as
  v_toate_notele note.valoare%type;
  v_note note.valoare%type;
  v_procent number(10);
  v_valoare number(5);
  v_note_peste_cinci note.valoare%type;
  v_formula number(5);
begin
   select count(valoare) into v_toate_notele from note n, cursuri c where n.id_curs=c.id_curs and c.id_curs=p_id_curs;
   select count(valoare) into v_note_peste_cinci from note n, cursuri c where n.id_curs=c.id_curs and c.id_curs=p_id_curs and valoare>=5;
   v_formula:=v_note_peste_cinci*100/v_toate_notele;
   dbms_output.put_line('rata promovabilitate pentru cursul: ' || p_id_curs || ' ' || v_formula || '%');
   for v_valoare in 5..10 loop
    if(v_valoare=5)
      then 
      select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=5;
      v_procent:=v_note/v_toate_notele*100;
      dbms_output.put_line('curs: ' || p_id_curs|| ' nota 5 ' || 'procent: ' || v_procent || '%' || rpad('*',v_procent,'*'));
      else if (v_valoare=6)
        then 
        select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=6;
        v_procent:=v_note/v_toate_notele*100;
        dbms_output.put_line('curs: ' || p_id_curs|| ' nota 6 ' || 'procent: ' || v_procent || '%'|| rpad('*',v_procent,'*'));
        else if (v_valoare=7)
          then 
          select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=7;
          v_procent:=v_note/v_toate_notele*100;
          dbms_output.put_line('curs: ' || p_id_curs|| ' nota 7 '|| 'procent: ' || v_procent || '%' || rpad('*',v_procent,'*'));
          else if (v_valoare=8)
            then 
            select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=8;
            v_procent:=v_note/v_toate_notele*100;
            dbms_output.put_line('curs: ' || p_id_curs|| ' nota 8 '|| 'procent: ' || v_procent || '%' || rpad('*',v_procent,'*'));
            else if (v_valoare=9)
              then 
              select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=9;
              v_procent:=v_note/v_toate_notele*100;
              dbms_output.put_line('curs: ' || p_id_curs|| ' nota 9 ' || 'procent: ' || v_procent || '%'|| rpad('*',v_procent,'*'));
              else if (v_valoare=10)
                then 
                select count(valoare) into v_note from note where p_id_curs=id_curs and valoare=10;
                v_procent:=v_note/v_toate_notele*100;
                dbms_output.put_line('curs: ' || p_id_curs|| ' nota 10 ' || 'procent: ' || v_procent || '%' || rpad('*',v_procent,'*'));
            end if;
          end if;
        end if;
      end if;
    end if;
  end if;
  end loop;
end rata_promovabilitate;

set serveroutput on;
begin
  rata_promovabilitate('22');
end;
