--3
set serveroutput on;
declare
  v_contor number(5);
  type cursuriList is table of cursuri.titlu_curs%TYPE;
  v_lista_cursuri cursuriList;
  cursor lista_cursuri is select titlu_curs from cursuri;
begin
    open lista_cursuri;
    fetch lista_cursuri bulk collect into v_lista_cursuri;
    close lista_cursuri;
    for v_contor in v_lista_cursuri.first..v_lista_cursuri.last loop
      dbms_output.put_line(v_lista_cursuri(v_contor));
    end loop;
end;