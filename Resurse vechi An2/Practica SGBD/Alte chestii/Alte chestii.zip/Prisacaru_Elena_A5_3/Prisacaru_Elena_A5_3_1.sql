--1
set serveroutput on;
DECLARE
   v_text varchar2(30) := 'Hello man';
   v_lungime number(5);
   v_contor number(5);
   v_vocale number(5) := 0;
BEGIN   
  v_lungime:=length(v_text);
   for v_contor in 1..v_lungime loop
      IF (upper(substr(v_text,v_contor,1)) in ('A','U','E','I','O'))
         THEN 
           v_vocale := v_vocale + 1;
       END IF;
    end loop;
    dbms_output.put_line ('nr. vocale' || ' ' ||  v_vocale);
END; 