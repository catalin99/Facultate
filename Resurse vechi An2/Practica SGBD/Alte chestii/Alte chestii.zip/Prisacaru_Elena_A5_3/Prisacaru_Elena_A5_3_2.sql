--2
drop table random_numbers;
create table random_numbers(
numbers number(20)
)

select * from random_numbers;

set serveroutput on;
declare
v_number number(5) :=  dbms_random.value(20,100); 
v_contor number(5);
begin
  for v_contor in 1..10 loop
      if v_number <> dbms_random.value(20,100)
         then insert into random_numbers values(dbms_random.value(20,100));
      end if;
  end loop;
end;

create or replace function gcd(num1 in number, num2 in number) return number is
v_n1 number := greatest(num1,num2);
    v_n2 number := least(num1,num2);
    v_r  number := -1;
    v_d  number := 0;
  begin
    loop
      exit when v_r = 0;
      v_r := v_n1 - (trunc(v_n1 / v_n2)*v_n2);
      v_d := v_n2;
      v_n1 := v_n2;
      v_n2 := v_r;
    end loop;
  return v_d;
end;


drop table gcd_1;
create table gcd_1(
text varchar2(100)
)

set serveroutput on;
declare
    v_prima_valoare random_numbers.numbers%TYPE;
    v_a_doua_valoare random_numbers.numbers%TYPE;
    rezultat random_numbers.numbers%TYPE;
    cursor lista_numere_1 is select numbers from random_numbers order by numbers asc;
    cursor lista_numere_2 is select numbers from random_numbers where numbers >v_prima_valoare order by numbers asc;
begin
  open lista_numere_1;
  loop
    fetch lista_numere_1 into v_prima_valoare;
    exit when lista_numere_1%notfound;
    open lista_numere_2;
       loop
       fetch lista_numere_2 into v_a_doua_valoare;
       exit when lista_numere_2%notfound;
          rezultat:=gcd(v_prima_valoare,v_a_doua_valoare);
          if rezultat=1 then
              dbms_output.put_line('nr ' || v_prima_valoare || ' si ' || v_a_doua_valoare || ' sunt prime intre ele ');
          else
              dbms_output.put_line('Cmmdc al nr ' || v_prima_valoare || ' si ' || v_a_doua_valoare || ' este ' || rezultat);
                    insert into gcd_1 values('cmmdc al nr ' || v_prima_valoare || ' si ' || v_a_doua_valoare || ' este ' || rezultat);
          end if;
       end loop;
       close lista_numere_2;
  end loop;
close lista_numere_1;
end;
