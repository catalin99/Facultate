--3
drop type linie;
create type linie is object(
  nr_matricol char(4),
  nume varchar2(10),
  prenume varchar2(10),
  an number(1)
);

drop procedure calcul_medie_5;
create procedure calcul_medie_5 (p_detalii in linie, p_medie out number) as
v_an studenti.an%type;
v_medie_an_doi note.valoare%type;
v_medie_an_trei note.valoare%type;
begin
  select an into v_an from studenti where p_detalii.nr_matricol=nr_matricol;
  select avg(valoare) into v_medie_an_doi from note n where p_detalii.nr_matricol=n.nr_matricol;
  select avg(valoare) into v_medie_an_trei from note n where p_detalii.nr_matricol=n.nr_matricol;
   if(v_an=3)
    then
    dbms_output.put_line('nume: ' || p_detalii.nume || ' medie: ' || v_medie_an_trei);
      else if(v_an=2)
      then
        dbms_output.put_line('nume: ' || p_detalii.nume || ' medie: ' || v_medie_an_doi);
        else if(v_an=1)
        then
          dbms_output.put_line('studentul este in anul 1, nu afisam medie');
          end if;
      end if;
  end if;
end;

set serveroutput on;
declare
  v_out number;
  v_detalii_1 linie;
  v_detalii_2 linie;
  v_detalii_3 linie;
begin
  v_detalii_1:=linie('111','Popescu','Bogdan',3);
  v_detalii_2:=linie('120','Pintilescu','Andrei',1);
  v_detalii_3:=linie('123','Bucur','Andreea',1);
  calcul_medie_5(v_detalii_1,p_medie=>v_out);
  calcul_medie_5(v_detalii_2,p_medie=>v_out);
  calcul_medie_5(v_detalii_3,p_medie=>v_out);
end;