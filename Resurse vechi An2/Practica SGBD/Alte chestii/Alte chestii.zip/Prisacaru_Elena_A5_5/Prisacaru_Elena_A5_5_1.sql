drop function adaugaSpatii;
create function adaugaSpatii(maxlen integer, v varchar2) return varchar2 is
  x integer;
  v_nr varchar2(10):=v;
begin
  x:=maxlen-length(v_nr);
  for v_contor in 1..x loop
      v_nr:=' ' || v_nr;
  end loop;
return v_nr;
end;
  
set serveroutput on;
declare
  type vector is table of integer index by pls_integer;
  type linii is table of vector index by pls_integer;
  matrice linii;
  matrice_2 linii;
  matrice_rezultat linii;
  v_linii number(5):=dbms_random.value(2,5);
  v_coloane number(5):=dbms_random.value(2,5);
  v_linii_2 number(5):=v_coloane;
  v_coloane_2 number(5):=dbms_random.value(2,5);
  v_suma number(5);
begin
  dbms_output.put_line('Matrice 1');
  for v_contor_i in 1..v_linii loop
    for v_contor_j in 1..v_coloane loop
      matrice(v_contor_i)(v_contor_j):=dbms_random.value(0,30);
      if matrice(v_contor_i)(v_contor_j)<10 then
        dbms_output.put(' ' || matrice(v_contor_i)(v_contor_j));
      else 
        dbms_output.put(matrice(v_contor_i)(v_contor_j));
      end if;
      dbms_output.put(' ');
    end loop;
    dbms_output.put_line('');
  end loop;
  
  dbms_output.put_line('Matrice 2');
  for v_contor_i_2 in 1..v_linii_2 loop
    for v_contor_j_2 in 1..v_coloane_2 loop
      matrice_2(v_contor_i_2)(v_contor_j_2):=dbms_random.value(0,30);
      if matrice_2(v_contor_i_2)(v_contor_j_2)<10 then
        dbms_output.put(' ' || matrice_2(v_contor_i_2)(v_contor_j_2));
      else
        dbms_output.put(matrice_2(v_contor_i_2)(v_contor_j_2));
      end if;
      dbms_output.put(' ');
    end loop;
    dbms_output.put_line('');
  end loop;
  
  for v_i in 1..v_linii loop
    for v_j in 1..v_coloane_2 loop
    v_suma:=0;
      for v_k in 1..v_linii_2 loop
        v_suma:=matrice(v_i)(v_k)*matrice_2(v_k)(v_j)+v_suma;
      end loop;
    matrice_rezultat(v_i)(v_j):=v_suma;
    end loop;
  end loop;
  
  dbms_output.put_line('Matrice rezultat');
  for v_contor_i_2 in 1..v_linii loop
    for v_contor_j_2 in 1..v_coloane_2 loop
      dbms_output.put(adaugaSpatii(4,matrice_rezultat(v_contor_i_2)(v_contor_j_2))||'');
      dbms_output.put(' ');
    end loop;
    dbms_output.put_line('');
  end loop;
end;
