--2
set serveroutput on;
declare
  cursor lista_nume_prenume is select nume, prenume from persoane;
  v_nume persoane.nume%type;
  v_prenume persoane.prenume%type;
  v_contor number(5):=0;
  v_numar_persoane_u number(5):=0;
begin
  open lista_nume_prenume;
  loop
  fetch lista_nume_prenume into v_nume, v_prenume;
  exit when lista_nume_prenume%notfound;
    while(v_contor<=v_prenume.last) loop
      if(v_prenume.exists(v_contor) and v_prenume(v_contor) like '%u%') then
        dbms_output.put(v_nume || ' ');
        for v_contor_2 in v_prenume.first..v_prenume.last loop
          dbms_output.put(' ' || v_prenume(v_contor_2));
        end loop;
        v_numar_persoane_u :=v_numar_persoane_u+1;
      end if;
      v_contor:=v_contor+1;
    end loop;
  end loop;
  close lista_nume_prenume;
  dbms_output.put_line(' ' || v_numar_persoane_u);
end;
