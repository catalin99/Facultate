--1 --2
drop package manager_facultate;
create package manager_facultate is
procedure adauga_student(p_nr_matricol varchar2,
                        p_nume varchar2,
                        p_prenume varchar2,
                        p_an integer,
                        p_grupa varchar2,
                        p_bursa integer,
                        p_data_nastere varchar2);
procedure sterge_student(p_nr_matricol studenti.nr_matricol%type);
procedure foaie_matricola(p_nr_matricol studenti.nr_matricol%type);
procedure inserare_nota(p_id_prof profesori.id_prof%type,
                        p_id_curs cursuri.id_curs%type,
                        p_nota note.valoare%type,
                        p_nr_matricol studenti.nr_matricol%type);
end manager_facultate;

drop package body manager_facultate;
create package body manager_facultate is
  procedure adauga_student(p_nr_matricol varchar2,
                        p_nume varchar2,
                        p_prenume varchar2,
                        p_an integer,
                        p_grupa varchar2,
                        p_bursa integer,
                        p_data_nastere varchar2) as
  v_nr_matricol studenti.nr_matricol%type;
  matricol_duplicat exception;
  pragma exception_init(matricol_duplicat,-20001);
  counter number(5);
  begin
  select count(*) into counter from studenti where nr_matricol=p_nr_matricol;
  if counter=0 then
      insert into studenti(nr_matricol,nume,prenume,an,grupa,bursa,data_nastere) values (p_nr_matricol, p_nume, p_prenume, p_an, p_grupa, p_bursa, p_data_nastere);
  else
  raise matricol_duplicat;
  end if;
   exception
  when matricol_duplicat then
    dbms_output.put_line('Nr matricol deja alocat ' || p_nume || ' ' || p_prenume);
  end adauga_student;

  procedure sterge_student(p_nr_matricol studenti.nr_matricol%type) as
  counter number(5);
  student_inexistent exception;
  pragma exception_init(student_inexistent, -20001);
  begin
  select count(*) into counter from studenti where nr_matricol = p_nr_matricol;
  if counter = 0 then
    raise student_inexistent;
  else 
    delete from studenti where studenti.nr_matricol=p_nr_matricol;
    dbms_output.put_line('Studentul a fost sters cu succes!');
  end if;
  exception
  when student_inexistent then
   raise_application_error(-20001, 'Studentul nu exista in baza de date, NOT OK');
  end sterge_student;

  procedure foaie_matricola(p_nr_matricol studenti.nr_matricol%type) as
    counter number(5);
    student_inexistent exception;
    pragma exception_init(student_inexistent, -20001);
    student_fara_note exception;
    pragma exception_init(student_fara_note, -20002);
    cursor v_inf is select valoare,c.titlu_curs,nr_matricol from note n, cursuri c where n.nr_matricol=p_nr_matricol and n.id_curs=c.id_curs;
    v_medie note.valoare%type;
    v_nume studenti.nume%type;
    v_nr_matricol studenti.nr_matricol%type;
    v_an studenti.an%type;
    begin
    select count(*) into counter from studenti s where p_nr_matricol=s.nr_matricol;
    if counter=0 then
     raise student_inexistent;
    else 
      select nvl(max(valoare),0) into counter from note n, cursuri c where n.nr_matricol=p_nr_matricol and n.id_curs=c.id_curs;
      if counter = 0 then
        raise student_fara_note;
    else
      select nume into v_nume from studenti where p_nr_matricol=nr_matricol;
      select an into v_an from studenti where p_nr_matricol=nr_matricol;
      for v_contor in v_inf loop
        dbms_output.put_line('Studentul cu numele ' || v_nume ||' si numarul matricol : ' || p_nr_matricol||' are la cursul: ' || v_contor.titlu_curs ||' are notele: '||v_contor.valoare);
      end loop;
      if v_an=1 then
      select avg(valoare) into v_medie from studenti s,note n where s.nr_matricol=n.nr_matricol and s.an=1 and p_nr_matricol=n.nr_matricol;
        dbms_output.put_line('Media pe anul ' || v_an || ' este ' || v_medie);
      end if;
      if v_an=2 then
      select avg(valoare) into v_medie from studenti s,note n, cursuri c where s.nr_matricol=n.nr_matricol and s.an=2 and p_nr_matricol=n.nr_matricol and n.id_curs=c.id_curs;
        dbms_output.put_line('Media pe anul ' || v_an || ' este ' || v_medie );
      end if;
      if v_an=3 then
      select avg(valoare) into v_medie from studenti s,note n, cursuri c where s.nr_matricol=n.nr_matricol and s.an=3 and p_nr_matricol=n.nr_matricol and n.id_curs=c.id_curs;
        dbms_output.put_line('Media pe anul ' || v_an || ' este'  || v_medie);
      end if;
    end if;
    end if;
    exception 
    when student_fara_note then
      raise_application_error(-20001, 'Studentul cu matricolul ' || p_nr_matricol || ' nu are nici o nota.');
    when student_inexistent then
      raise_application_error(-20002, 'Studentul nu exista in baza de date');
    end foaie_matricola;
  
  procedure inserare_nota(p_id_prof profesori.id_prof%type,
                        p_id_curs cursuri.id_curs%type,
                        p_nota note.valoare%type,
                        p_nr_matricol studenti.nr_matricol%type) as
    v_prof profesori.id_prof%type;
    v_id_curs cursuri.id_curs%type;
    counter number(5);
    prof_invalid exception;
    pragma exception_init(prof_invalid, -20001);
    begin
    select id_prof into v_prof from profesori where id_prof=p_id_prof;
    select id_curs into v_id_curs from cursuri where id_curs=p_id_curs;
    select count(*) into counter from profesori p, cursuri c, didactic d where p.id_prof=d.id_prof and c.id_curs=d.id_curs and p.id_prof=v_prof and c.id_curs=v_id_curs;
    if(counter=0) then 
      raise prof_invalid; 
    end if;
    insert into note values(p_nr_matricol, v_id_curs, p_nota, null);
    dbms_output.put_line('Nota a fost inserata cu succes!');
    exception 
    when prof_invalid then
      raise_application_error(-20001, 'Profesorul nu poate pune note, NOT OK');
  end inserare_nota;
end manager_facultate;

set serveroutput on;
begin
   manager_facultate.adauga_student('200','Becali', 'Gigi',1,'A5',450,'28-MAY-1965');
end;

set serveroutput on;
begin
   manager_facultate.sterge_student('9999');
end;

set serveroutput on;
begin
   manager_facultate.sterge_student('200');
end;

set serveroutput on;
begin
   manager_facultate.foaie_matricola('119');
end;

set serveroutput on;
begin
   manager_facultate.foaie_matricola('123');
end;

set serveroutput on;
begin
   manager_facultate.foaie_matricola('999');
end;

set serveroutput on;
begin
   manager_facultate.inserare_nota('p1','26',11,'123');
end;

set serveroutput on;
begin
   manager_facultate.inserare_nota('p9','26',11,'123');
end;

--2

drop table studenti_transferati;
create table studenti_transferati(
nr_matricol char(3) not null,
nume varchar2(10),
prenume varchar2(10),
an number(1,0),
grupa char(2),
bursa number(6,2),
data_nastere date
);

insert into studenti_transferati values ('500','P1','E1',2,'B2',450,null);
insert into studenti_transferati values ('123','P2','E2',3,'B1',350,null);
insert into studenti_transferati values ('111','P3','E3',1,'B7',250,null);
insert into studenti_transferati values ('119','P4','E4',2,'B5',100,null);
insert into studenti_transferati values ('504','P5','E5',3,'A5',500,null);
insert into studenti_transferati values ('505','P6','E6',1,'A7',450,null);
insert into studenti_transferati values ('506','P7','E7',2,'A3',450,null);
insert into studenti_transferati values ('507','P8','E8',3,'A2',300,null);
insert into studenti_transferati values ('508','P9','E9',1,'A2',350,null);
insert into studenti_transferati values ('509','P10','E10',2,'B2',450,null);
insert into studenti_transferati values ('510','P11','E11',2,'B2',450,null);


set serveroutput on;
declare
  cursor lista_transferati is select nr_matricol,nume,prenume,an,grupa,bursa,data_nastere from studenti_transferati;
  type matr_list is table of studenti_transferati.nr_matricol%type;
  nrMat matr_list;
  type nume_prenume_list is table of studenti_transferati.nume%type;
  nume_list nume_prenume_list;
  prenume_list nume_prenume_list;
  type an_list is table of studenti_transferati.an%type;
  aN an_list;
  type grupa_list is table of studenti_transferati.grupa%type;
  grupaList grupa_list;
  type bursa_list is table of studenti_transferati.bursa%type;
  bursaList bursa_list;
  type data_nastere_list is table of studenti_transferati.data_nastere%type;
  dataNastere data_nastere_list;
begin
    open lista_transferati;
    fetch lista_transferati bulk collect into nrMat,nume_list,prenume_list,aN,grupaList,bursaList,dataNastere;
    for i in 1..nrMat.count loop
      manager_facultate.adauga_student(nrMat(i),nume_list(i),prenume_list(i),aN(i),grupaList(i),bursaList(i),dataNastere(i));
    end loop;
    close lista_transferati;
end;