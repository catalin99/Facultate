
import java.sql.*;

class PLSQLExample
{
    public static void main (String args []){
        try{
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@85.122.23.37:1521:xe", "stud13", "Acdcrideon1");
            CallableStatement stmt = con.prepareCall("{ ? = call return_sal(?) }");
            stmt.registerOutParameter(1, Types.INTEGER);
            stmt.setInt(2, 7782);
            System.out.println("empno="+7782);
            stmt.execute();
            System.out.println("Salariul este: "+stmt.getObject(1));
            // Close the connection
            con.close();
        }catch (SQLException ex){
            if(ex.getErrorCode()==1403){
                System.out.println("Angajat inexistent");
            }
            else System.out.println("Ciudat...la asta nu m-am asteptat");
        }

        try{
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@85.122.23.37:1521:xe","stud13","Acdcrideon1");
            CallableStatement stmt = con.prepareCall("{ ? = call return_sal(?) }");
            stmt.registerOutParameter(1, Types.INTEGER);
            stmt.setInt(2, 254);
            System.out.println("empno="+254);
            stmt.execute();
            System.out.println("Salariul este: "+stmt.getObject(1));
            // Close the connection
            con.close();
        }catch (SQLException ex){
            if(ex.getErrorCode()==1403){
                System.out.println("Angajat inexistent");
            }
            else System.out.println("Ciudat...la asta nu m-am asteptat");
        }



    }
}

/*CREATE OR REPLACE FUNCTION return_sal(nmb IN INTEGER) RETURN INTEGER IS
  sal INTEGER:=0;
BEGIN
  SELECT SAL INTO sal FROM EMP WHERE EMPNO=nmb;
   IF SQL%NOTFOUND THEN RAISE_APPLICATION_ERROR(-1403,'ANGAJAT INEXISTENT');
   ELSE RETURN sal;
   END IF;
END;
/
*/