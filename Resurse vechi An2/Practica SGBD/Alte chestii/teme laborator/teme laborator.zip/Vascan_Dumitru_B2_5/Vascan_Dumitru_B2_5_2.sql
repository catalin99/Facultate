--procedura care va mari salarii cu 500
CREATE OR REPLACE PROCEDURE majorare IS
BEGIN
UPDATE EMP SET SAL=SAL + 500 WHERE JOB='MANAGER';
END;
/

--bloc anonim in care se ruleaza procedura de majorare prinde exceptia personalizata sal>3000
DECLARE
  exceptie EXCEPTION;
BEGIN
  majorare;
  FOR curs IN (SELECT * FROM EMP WHERE JOB='MANAGER') LOOP
    BEGIN
      IF curs.SAL>3000 THEN
        DBMS_OUTPUT.PUT_LINE('MANAGER: '||curs.ENAME||' SALARIUL NOU: '|| 3000 ||' MAJORARE: '|| (3000-(curs.SAL-500)));
        RAISE exceptie;
      ELSE
        DBMS_OUTPUT.PUT_LINE('MANAGER: '||curs.ENAME||' SALARIUL NOU: '||curs.SAL||' MAJORARE: '||500);
      END IF; 
      EXCEPTION
        WHEN exceptie THEN
          UPDATE EMP SET EMP.SAL=3000 WHERE EMP.EMPNO=curs.EMPNO;
    END;
  END LOOP;
END;
/