set serveroutput on;
--ex 1--
DECLARE
	nume_prenume emp.ename%type;
	lungime int;
BEGIN
	select  initcap(lower(ename)), length(trim(ename)) into nume_prenume,lungime
	from emp
	where length(trim(ename))=(select max(length(trim(ename))) from emp) and rownum=1;
	dbms_output.put_line('Nume cu/fara prenume: ' || nume_prenume || ' Lungimea numelui: ' || lungime);
END;
/

--ex2--
DECLARE
	constanta CONSTANT VARCHAR2(30) :='17-07-1994';
	day_of_week VARCHAR2(20):=TO_CHAR(TO_DATE(constanta,'DD-MM-YYYY'),'DAY');
	days INT:=(SYSDATE-TO_DATE(constanta,'DD-MM-YYYY'))+1;
	months INT:=MONTHS_BETWEEN(SYSDATE,TO_DATE(constanta,'DD-MM-YYYY'));
BEGIN
	dbms_output.put_line( 'Ziua saptamanii: '|| day_of_week || 'Luni: ' || months ||' Zile: '||days);
END;
/

--ex3--
<<outer>>
DECLARE
	variabila int:=1;
	variabila_1 int:=2;
	PROCEDURE inner IS
	variabila int:=3;
	variabila_2 int:=4;
	BEGIN
		dbms_output.put_line('Var_loc suprascrie var_glob ' || variabila || ' Var doar locala: ' || variabila_2 || ' Var globala: ' || outer.variabila );
	END;
BEGIN
	inner;
END;
/
