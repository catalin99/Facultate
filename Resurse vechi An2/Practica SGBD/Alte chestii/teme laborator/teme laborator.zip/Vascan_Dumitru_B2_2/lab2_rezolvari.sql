set serveroutput on;

--ex 1--
DROP TABLE Fibonacci;
CREATE TABLE Fibonacci
(
	id int,
	valoare int
);
DECLARE
	prec_prec_nmb int:=1;
	prec_nmb int:=1;
	curr_nmb int:=2;
	fib_counter int:=1;
BEGIN
	WHILE curr_nmb<1000 LOOP
		INSERT INTO Fibonacci VALUES(fib_counter,curr_nmb);
		prec_prec_nmb:=prec_nmb;
		prec_nmb:=curr_nmb;
		curr_nmb:=prec_prec_nmb+prec_nmb;
		fib_counter:=fib_counter+1;
	END LOOP;
END;
/

--ex 2--
DROP TABLE primes;
CREATE TABLE primes
(
	id int,
	valoare int
);
DECLARE
	prime_counter int:=0;
	ok int;
	heWhoDivides int;
BEGIN
	FOR i IN 2..1999
	LOOP
		ok:=1;
		heWhoDivides:=2;
		LOOP
			EXIT WHEN heWhoDivides>SQRT(i);
			IF MOD(i,heWhoDivides)=0
			THEN
				ok:=0;
				EXIT;
			ELSE
				heWhoDivides:=heWhoDivides+1;
			END IF;
		END LOOP;	
		IF ok=1
		THEN
			prime_counter:=prime_counter+1;
			INSERT INTO primes VALUES (prime_counter,i);
		END IF;		
	END LOOP;
	DELETE FROM primes WHERE valoare>1500 and valoare<1800;
	dbms_output.put_line('Au fost sterse ' || SQL%ROWCOUNT || ' randuri');
END;
/

--ex3--
DROP TABLE FiboPrime;
CREATE TABLE FiboPrime
(
	prime int,
	value int	
);
	INSERT INTO FiboPrime SELECT * FROM Fibonacci;

	MERGE INTO FiboPrime f
	USING primes p 
	ON (f.value = p.valoare)
	WHEN MATCHED THEN
		UPDATE SET
			f.prime = 1 

/

	UPDATE FiboPrime SET prime=0 WHERE prime<>1;
/

SELECT * FROM FIBONACCI;
SELECT * FROM PRIMES;
SELECT * FROM FIBOPRIME;