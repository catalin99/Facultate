#pragma once
class Forma
{
public:
	virtual void Paint() = 0;
};

