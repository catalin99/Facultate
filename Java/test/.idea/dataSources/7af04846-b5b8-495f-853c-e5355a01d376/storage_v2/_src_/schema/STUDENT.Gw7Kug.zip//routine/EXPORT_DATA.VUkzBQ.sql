create procedure export_data
is
  fisier UTL_FILE.FILE_TYPE;
  p_obj CLOB;
  p_query VARCHAR2(300);
begin
  fisier := UTL_FILE.FOPEN ('MYDIR', 'Export.sql', 'W');
  
  FOR i IN (SELECT * FROM USER_OBJECTS WHERE OBJECT_TYPE='TABLE' AND OBJECT_NAME='STUDENTI') LOOP
    SELECT DBMS_METADATA.GET_DDL(i.OBJECT_TYPE,i.OBJECT_NAME) 
    INTO p_obj 
    FROM dual;
    --dbms_output.put_line(myObject);
    UTL_FILE.PUT_LINE(fisier,p_obj);
  END LOOP;
 
 FOR i IN (SELECT * FROM USER_OBJECTS WHERE OBJECT_TYPE='TABLE' AND OBJECT_NAME='PRIETENI') LOOP
    SELECT DBMS_METADATA.GET_DDL(i.OBJECT_TYPE,i.OBJECT_NAME) 
    INTO p_obj 
    FROM dual;
    --dbms_output.put_line(myObject);
    UTL_FILE.PUT_LINE(fisier,p_obj);
  END LOOP;
 
  UTL_FILE.FCLOSE (fisier);
END;
/

