create PROCEDURE pow (p_baza IN Integer := 3, p_exponent IN INTEGER DEFAULT 5) AS
   v_rezultat INTEGER;
BEGIN
    v_rezultat := p_baza ** p_exponent;
    DBMS_OUTPUT.PUT_LINE(v_rezultat);
END;
/

