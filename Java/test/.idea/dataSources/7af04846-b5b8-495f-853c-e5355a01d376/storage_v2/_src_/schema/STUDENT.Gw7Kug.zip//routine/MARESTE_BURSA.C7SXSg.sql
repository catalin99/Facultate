create procedure mareste_bursa (pi_studenti studenti_burse) is
  burse istoric_burse;
  v_bursa number;
  v_count number;
begin
  for c in (select id_student, procent_marire from table(pi_studenti)) loop
  
    select * into burse from (select nvl(SCHIMBARI_BURSA, istoric_burse()) from studenti where id = c.id_student);
    select bursa into v_bursa from (select bursa from studenti where id = c.id_student);
    if (burse = null) then
      burse := istoric_burse(v_bursa);
    else
      v_count := burse.count;
      burse.extend(1);
      burse(v_count+1) := v_bursa;
    end if;
    
    update studenti 
    set bursa = nvl(bursa,100) + (1+c.procent_marire), SCHIMBARI_BURSA = burse
    where id = c.id_student;
    
  end loop;
end mareste_bursa;
/

