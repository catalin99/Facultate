create procedure delete_tables
is
  cursor c1 is 
  select object_type,object_name 
  from user_objects 
  where object_type = 'TABLE';
begin
  for c1_record in c1 loop
    execute immediate ('drop '||c1_record.object_type||' ' ||c1_record.object_name||' cascade constraints');
  end loop;
end;
/

