create procedure functie 
is 
  nume_student_arr   vc_arr;
  prenume_student_arr   vc_arr;
begin
  delete from tabela;--am pus delete ca la fiecare rulare sa insereze doar o data !
  select nume, prenume
  bulk collect into nume_student_arr, prenume_student_arr
  from
  (select nume , prenume
  from studenti s join note n on s.id=n.id_student join cursuri c on c.id=n.id_curs where titlu_curs like 'Baze de date' and valoare=10 and
  (s.prenume like '%u%' or s.prenume like 'U%'));

  if nume_student_arr.count<>0 then 
    forall i in nume_student_arr.first .. nume_student_arr.last
      insert into tabela(nume, prenume) values (nume_student_arr(i), prenume_student_arr(i));
  end if;
  DBMS_OUTPUT.PUT_LINE(nume_student_arr.count);
end;
/

