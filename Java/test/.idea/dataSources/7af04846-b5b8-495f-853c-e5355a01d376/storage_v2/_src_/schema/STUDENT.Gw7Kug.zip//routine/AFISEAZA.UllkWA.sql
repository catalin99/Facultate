create PROCEDURE afiseaza AS
   my_name varchar2(20):='Gigel';
BEGIN
   DBMS_OUTPUT.PUT_LINE('Ma cheama ' || my_name);
END afiseaza;
/

