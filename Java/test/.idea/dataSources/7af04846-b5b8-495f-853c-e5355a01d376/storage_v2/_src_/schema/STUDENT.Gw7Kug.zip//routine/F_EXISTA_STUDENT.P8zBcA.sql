create function f_exista_student(IN_id_student in studenti.id%type) return boolean
  is
    e_std boolean;
    p_number number;--0 daca studentul nu exista, 1 daca exista
  begin
    select count(*)
    into p_number
    from studenti
    where id=IN_id_student;
    if p_number=0 then
      dbms_output.put_line('Studentul cu id-ul '||IN_id_student||' nu exista in baza de date !');
      e_std:=false;
      --return false;
    else
      e_std:=true;
      --return true;
    end if;
    return e_std;
  end f_exista_student;
/

