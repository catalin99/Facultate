create function get_students_id return num_arr
is
  p_students_id_arr num_arr;
begin
  select student_id
  bulk collect into p_students_id_arr
  from
  (select s.id as student_id
  from studenti s join note n on n.id_student = s.id join cursuri c on c.id = n.id_curs
  where titlu_curs = 'Baze de date' and valoare = 10);
  return p_students_id_arr;
end;
/

