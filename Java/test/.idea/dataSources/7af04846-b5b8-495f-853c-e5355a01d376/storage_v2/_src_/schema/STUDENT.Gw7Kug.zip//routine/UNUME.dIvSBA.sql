create procedure unume 
is
  nume_student_arr vc_arr;
  prenume_student_arr vc_arr;
  p_nr number;
begin
  select s.nume, s.prenume bulk collect into nume_student_arr, prenume_student_arr, p_nr
    from studenti s join note n on s.id=n.id_student 
    join cursuri c on c.id=n.id_curs
    where n.valoare=10 and c.titlu_curs='Baze de date' and (s.prenume like '%u%' or s.prenume like 'U%');
 
 if nume_student_arr.count<>0 then 
    forall i in nume_student_arr.first .. nume_student_arr.last
      insert into UStudenti(nume, prenume) values(nume_student_arr(i), prenume_student_arr(i));
  end if;
    DBMS_OUTPUT.PUT_LINE(nume_student_arr.count);
end;
/

