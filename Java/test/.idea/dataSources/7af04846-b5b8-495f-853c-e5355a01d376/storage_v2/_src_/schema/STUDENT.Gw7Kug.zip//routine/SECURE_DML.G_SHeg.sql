create procedure secure_dml
is
begin
  if to_char(sysdate,'dy') in ('sat','sun') or to_char(sysdate,'HH24:MI') not between '08:45' and '17:30' then
    raise_application_error(-20400,'Se pot efectua modificari asupra datelor doar in timpul orelor de program') ;
  end if;
end;
/

