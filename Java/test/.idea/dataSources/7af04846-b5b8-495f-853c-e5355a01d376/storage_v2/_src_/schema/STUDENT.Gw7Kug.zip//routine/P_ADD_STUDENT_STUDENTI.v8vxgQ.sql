create procedure p_add_student_studenti
  is
    p_count number :=0;
    p_nr_nume number :=100;
    p_nr_prenume number :=100;
    p_temp number :=0;
    p_nume varchar2(15);
    p_prenume varchar2(15);
    p_an_random number;
    p_grupa_random varchar2(2);
    p_id_curs cursuri.id%type;
    p_matr studenti.nr_matricol%type;
    p_max_id_student studenti.id%type;
  begin
    p_matr:= floor(dbms_random.value(100,999)) || chr(floor(dbms_random.value(65,91))) || 
      chr(floor(dbms_random.value(65,91))) || chr(floor(dbms_random.value(0,9)));
    --cati studenti sunt dupa nume
    select count(*) 
    into p_nr_nume 
    from inume;
   --cati studenti sunt dupa prenume
    select count(*) 
    into p_nr_prenume
    from iprenume;         
    loop
      p_temp := trunc(dbms_random.value(1,p_nr_nume));
      select nume 
      into p_nume 
      from inume 
      where nr = p_temp; 
         
      p_temp := trunc(dbms_random.value(1,p_nr_prenume));      
      select prenume 
      into p_prenume 
      from iprenume 
      where nr = p_temp;
                  
      select count(*) 
      into p_temp 
      from studenti
      where nume=p_nume and prenume=p_prenume;
    
      if(p_temp = 0) then
        select max(id) 
        into p_temp 
        from studenti;
        p_temp := p_temp + 1;
        p_an_random := trunc(dbms_random.value(1,4));
       
        insert into studenti(id, nr_matricol, nume, prenume, an, created_at, updated_at) values (p_temp, p_matr, p_nume, p_prenume, p_an_random, sysdate, sysdate);
          p_count := p_count + 1;
        exit when p_count = 1;
         
      end if;  
    end loop;
  end p_add_student_studenti;
/

