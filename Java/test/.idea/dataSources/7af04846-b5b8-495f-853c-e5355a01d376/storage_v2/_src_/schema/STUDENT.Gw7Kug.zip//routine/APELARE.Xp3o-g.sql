create procedure apelare as
    v_lista_obiecte_apelare lista_obiecte := lista_obiecte();
begin
  v_lista_obiecte_apelare := afisareDeInformatiiFunctie2;
  for i in 1..v_lista_obiecte_apelare.count loop
    dbms_output.put_line(v_lista_obiecte_apelare(i).tip || ' ' || v_lista_obiecte_apelare(i).nume);  
  end loop;
end;
/

