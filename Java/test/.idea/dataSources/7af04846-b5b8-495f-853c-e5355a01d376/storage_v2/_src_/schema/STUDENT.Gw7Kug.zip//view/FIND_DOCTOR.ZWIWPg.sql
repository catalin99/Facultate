create view FIND_DOCTOR as
select nume, prenume, tip_animal from doctori, tip_animal, specializare 
    where specializare.id_doctor=doctori.id and specializare.id_animal=tip_animal.id
/

