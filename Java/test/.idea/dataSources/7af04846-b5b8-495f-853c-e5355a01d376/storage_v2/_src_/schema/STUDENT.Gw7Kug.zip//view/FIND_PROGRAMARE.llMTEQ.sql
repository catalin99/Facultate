create view FIND_PROGRAMARE as
select nume, prenume, data, ora from doctori, programari
  where doctori.id=programari.id_doctor
/

