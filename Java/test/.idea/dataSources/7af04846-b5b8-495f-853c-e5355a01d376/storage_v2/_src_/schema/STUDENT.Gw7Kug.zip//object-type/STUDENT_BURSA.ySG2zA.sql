create type student_bursa as object (id_student char(4), procent_marire number);
/

