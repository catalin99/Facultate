create PROCEDURE p_medii_var(IN_id_student IN studenti.id%type, OUT_medie1 OUT float, OUT_medie2 OUT float)
AS
  p_an number(1);
  p_exist boolean;
BEGIN
  p_exist := f_exista_student(IN_id_student);
  if p_exist = true then
    select an 
    into p_an 
    from studenti
    where id=IN_id_student;
    if (p_an=1) then 
      DBMS_OUTPUT.PUT_LINE('Studentul cu id-ul ' ||IN_id_student|| ' este in anul 1 si nu are medie !');
    elsif(p_an=2) then
      select trunc(avg(valoare),2)
      into OUT_medie1
      from note n join cursuri c on c.id=n.id_curs
      where id_student=IN_id_student and an=1;
      DBMS_OUTPUT.PUT_LINE('Media din anul I este : ' || OUT_medie1);
    elsif(p_an=3) then
      select trunc(avg(valoare),2)
      into OUT_medie1
      from note n join cursuri c on c.id=n.id_curs
      where id_student=IN_id_student and an=1;
      DBMS_OUTPUT.PUT_LINE('Media din anul I este : ' || OUT_medie1);
      select trunc(avg(valoare),2)
      into OUT_medie2
      from note n join cursuri c on c.id=n.id_curs
      where id_student=IN_id_student and an=2;
      DBMS_OUTPUT.PUT_LINE('Media din anul II este : ' || OUT_medie2);
    else null;  
    end if;
  end if;
end;
/

