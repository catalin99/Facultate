create view FIND_PROGRAMARE_FOR_DOCTORI as
select nume, varsta, data, ora, motiv from pacienti, programari where programari.id_pacient=pacienti.id
/

