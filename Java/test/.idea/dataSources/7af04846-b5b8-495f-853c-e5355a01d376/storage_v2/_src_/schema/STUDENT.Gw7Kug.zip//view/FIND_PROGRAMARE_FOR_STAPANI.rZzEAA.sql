create view FIND_PROGRAMARE_FOR_STAPANI as
select nume, prenume, data, ora from doctori, programari
    where doctori.id=programari.id_doctor
/

