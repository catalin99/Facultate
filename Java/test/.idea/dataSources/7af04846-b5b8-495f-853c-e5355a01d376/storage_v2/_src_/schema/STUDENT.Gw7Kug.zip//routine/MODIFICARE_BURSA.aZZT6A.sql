create PROCEDURE modificare_bursa(IN_id_student in studenti.id%type) as
    p_year NUMBER;
    p_bursa NUMBER;
    p_bursaModificata NUMBER;
    begin
        select substr(extract(year from data_nastere),4,1) into p_year from studenti where id=IN_id_student;
        select bursa into p_bursa from studenti where bursa is not null and id=IN_id_student;
        p_bursaModificata := p_bursa + p_year;
    end modificare_bursa;
/

