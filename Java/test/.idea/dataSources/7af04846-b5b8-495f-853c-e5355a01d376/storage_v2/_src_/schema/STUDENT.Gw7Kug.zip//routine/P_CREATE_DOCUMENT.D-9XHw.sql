create procedure p_create_document 
is
  v_fisier UTL_FILE.FILE_TYPE;
begin
  v_fisier:=UTL_FILE.FOPEN('MYDIR','myfile.txt','W');
  UTL_FILE.PUTF(v_fisier,'abcdefg');
  UTL_FILE.FCLOSE(v_fisier);
end;
/

