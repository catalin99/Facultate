create procedure p_zodiac 
is 
  type zodii_table_arr is record (nume_zodie_arr varchar2(20), distributie_arr number);
  type items_zodii_table_arr is table of zodii_table_arr;
  l_items_zodii_table_arr items_zodii_table_arr:=items_zodii_table_arr();
begin
  delete from zodii_distributii;
  select nume_zodie_arr, distributie_arr
  bulk collect into l_items_zodii_table_arr
  from
  (select nume_zodie as nume_zodie_arr, count(*) as distributie_arr
  from zodiac z left join studenti s on to_date(to_char(s.data_nastere,'DD-MM'),'DD-MM') between to_date(z.data_inceput, 'DD-MM') and to_date(z.data_sfarsit, 'DD-MM')
  group by nume_zodie);

  if l_items_zodii_table_arr.count <> 0 then
    forall i in l_items_zodii_table_arr.first .. l_items_zodii_table_arr.last
      insert into zodii_distributii(zodie, numar_studenti) values (l_items_zodii_table_arr(i).nume_zodie_arr, l_items_zodii_table_arr(i).distributie_arr);
  end if;
end;
/

