package gui;

import java.awt.*;

public interface Display {
    public Color getColor();
}
