package com.company;

import gui.DrawingFrame;

public class Main {

    public static void main(String[] args) {
	    new DrawingFrame().setVisible(true);
    }
}
